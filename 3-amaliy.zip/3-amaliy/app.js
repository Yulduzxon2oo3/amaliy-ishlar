// 8.	s yuza sm2 larda berilgan. Uni dm2 lardagi qiymati hisoblansin


let a=prompt(`Yuzani sm da ni kiritng:`);
let S=a/100;
console.log(`${S}dm kvadratga teng`);